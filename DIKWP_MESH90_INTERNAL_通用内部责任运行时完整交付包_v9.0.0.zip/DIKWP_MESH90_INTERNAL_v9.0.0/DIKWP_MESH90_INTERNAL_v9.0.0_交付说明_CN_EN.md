# DIKWP-MESH9.0 Internal Runtime Delivery Guide / 交付说明

## 中文

本交付为**通用内部责任运行时**，与段玉聪或任何特定个人、单位、公司、专利、医院、活动和调查案件无关。所有示例均为合成治理载体。

### 核心命令

```bash
python mesh90.py summary
python mesh90.py conformance
python mesh90.py run examples/full_closure.mesh90.json --out outputs/run.json --dashboard outputs/run.html
python mesh90.py replay outputs/run.json
python mesh90.py demo-all --out-dir outputs/demos
python mesh90.py public-bridge outputs/run.json --out outputs/public.json
```

也可运行：

```bash
python dist/DIKWP_MESH90_INTERNAL_v9.0.0.pyz conformance
pip install dist/dikwp_mesh90_internal-9.0.0-py3-none-any.whl
mesh90 conformance
```

### 核心边界

- 隶属、上下级、任职、共同作者、研究合作、活动、媒体、托管、评测、引用、标准参与、相似和先行技术均不自动构成采用。
- confirmed adoption 仅允许四类实施型关系，并要求S2+证据、明确载体、来源和独立范围断言。
- 推荐 != 授权 != 执行 != 效果 != 验收。
- 本地交付闭合 != 外部世界效果闭合。
- 工具可完成的工作不得静默推回用户。
- 纠错必须保留旧版本并传播到受影响对象。

## English

This release is a **generic internal responsibility runtime**. It contains no Duan-specific or organization-specific investigation data. All examples are synthetic governance carriers.

Core boundaries:

- Affiliation, hierarchy, appointment, coauthorship, collaboration, event, media, hosting, evaluation, citation, standards participation, similarity, and prior art do not establish adoption.
- Confirmed adoption is limited to four implementation relation types and requires S2+ evidence, an explicit carrier, sources, and a non-derived scope assertion.
- Recommendation != authority != execution != effect != acceptance.
- Local delivery closure != external-world effect closure.
- Tool-available work cannot be silently dumped back to the user.
- Correction preserves superseded versions and propagates to affected objects.
