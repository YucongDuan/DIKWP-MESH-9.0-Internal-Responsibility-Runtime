# Mesh9.0 Correction Note / 纠错说明

## 中文

此前把“86个相关单位”放进Mesh9.0本体，是一个架构错误：该表混合了隶属、共同作者、研究合作、活动主办/协办/承办、媒体报道、内容托管、评测对象、引用、标准参与、结构相似、先行技术、项目关系和少数直接实施。

新Mesh9.0作出以下不可逆纠正：

1. 核心运行时不包含任何个人、公司、单位调查表或案例数据。
2. 旧关系表不能迁移为采用证据；只能迁移为外部关系断言，默认 adoption_status=not_claimed。
3. affiliation、organizational_subordination、employment_appointment、coauthorship、research_collaboration、event_*、media_report、content_host、evaluation_*、citation、standard participation、structural similarity等均为非采用关系。
4. 只有 DIRECT_IMPLEMENTATION、COMMERCIAL_DEPLOYMENT、LICENSED_USE、PRODUCTION_INTEGRATION 是采用型关系。
5. confirmed adoption 还必须同时满足：S2+证据、明确实施载体、来源引用、非跨范围推断。
6. 关系数量、页面数量或覆盖数量不再是Mesh9.0内部闭合条件。

## English

Embedding an “86 related units” register into the Mesh9.0 core was an architectural error. The table mixed affiliation, coauthorship, research collaboration, event roles, media reporting, content hosting, evaluation subjects, citations, standards participation, structural similarity, prior art, project relations, and a small number of direct implementation relations.

The corrected Mesh9.0 makes the following irreversible changes:

1. The core runtime contains no person, company, organization-investigation register, or case data.
2. A legacy relation table cannot migrate as adoption evidence. It migrates only as external relation assertions with adoption_status=not_claimed by default.
3. Affiliation, organizational subordination, appointment, coauthorship, collaboration, event, media, hosting, evaluation, citation, standards participation, and similarity are non-adoption relations.
4. Only DIRECT_IMPLEMENTATION, COMMERCIAL_DEPLOYMENT, LICENSED_USE, and PRODUCTION_INTEGRATION are adoption-capable relation types.
5. Confirmed adoption also requires S2+ evidence, an explicit carrier, source references, and a non-derived scope assertion.
6. Relation count, page count, and coverage count are not Mesh9.0 closure criteria.
